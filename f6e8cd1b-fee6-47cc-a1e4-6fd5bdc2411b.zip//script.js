var canvas = document.getElementById("canvas");
var ctx = canvas.getContext("2d");
var currentTool = "brush";
var isDrawing = false;
var lastX, lastY;

function changeTool(tool) {
  currentTool = tool;
}

function draw(e) {
  if (!isDrawing) return;

  var x = e.clientX - canvas.offsetLeft;
  var y = e.clientY - canvas.offsetTop;

  switch (currentTool) {
    case "brush":
      ctx.lineWidth = 5;
      ctx.strokeStyle = "#000";
      ctx.lineCap = "round";
      ctx.beginPath();
      ctx.moveTo(lastX, lastY);
      ctx.lineTo(x, y);
      ctx.stroke();
      break;
    case "eraser":
      ctx.clearRect(x - 10, y - 10, 20, 20);
      break;
    case "line":
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.lineWidth = 5;
      ctx.strokeStyle = "#000";
      ctx.beginPath();
      ctx.moveTo(lastX, lastY);
      ctx.lineTo(x, y);
      ctx.stroke();
      break;
    case "rectangle":
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.lineWidth = 5;
      ctx.strokeStyle = "#000";
      ctx.strokeRect(lastX, lastY, x - lastX, y - lastY);
      break;
  }

  lastX = x;
  lastY = y;
}

canvas.addEventListener("mousedown", function (e) {
  isDrawing = true;
  lastX = e.clientX - canvas.offsetLeft;
  lastY = e.clientY - canvas.offsetTop;
});

canvas.addEventListener("mousemove", draw);

canvas.addEventListener("mouseup", function () {
  isDrawing = false;
});

function clearCanvas() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
}

function loadImage(e) {
  var file = e.target.files[0];
  var reader = new FileReader();
  reader.onload = function (event) {
    var img = new Image();
    img.onload = function () {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
    };
    img.src = event.target.result;
  };
  reader.readAsDataURL(file);
}

function saveImage() {
  var link = document.createElement("a");
  link.download = "image.png";
  link.href = canvas.toDataURL("image/png");
  link.click();
}
